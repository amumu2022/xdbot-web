import{_ as m}from"./description.vue_vue_type_style_index_0_lang-b2bba33a.js";import"./index-2459e2ab.js";export{m as default};
