import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-255bb42f.js";import"./index-3e9ad639.js";import"./index-62eb8096.js";import"./xdteam-f9b73a7f.js";export{o as default};
