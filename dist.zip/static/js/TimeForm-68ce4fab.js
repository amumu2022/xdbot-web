import{_ as o}from"./TimeForm.vue_vue_type_script_setup_true_lang-bcb7e3ef.js";import"./index-f983c796.js";import"./index-741268f1.js";export{o as default};
