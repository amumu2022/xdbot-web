const t={width:1024,height:1024,body:'<path fill="currentColor" d="M512 320L192 704h639.936z"/>'},o=t;export{o as f};
