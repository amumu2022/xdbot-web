import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-927a1803.js";import"./index-2638da33.js";import"./index-d5bf77ac.js";export{o as default};
