import{a0 as o}from"./index-825ff3e3.js";const a=o({});export{a as f};
