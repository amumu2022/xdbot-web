import{_ as o}from"./role.vue_vue_type_script_setup_true_lang-9a6ea813.js";import"./index-3e9ad639.js";import"./index-62eb8096.js";export{o as default};
