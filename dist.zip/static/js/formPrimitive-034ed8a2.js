import{_ as m}from"./formPrimitive.vue_vue_type_script_setup_true_lang-e0e4a45f.js";import"./index-302c85c2.js";export{m as default};
