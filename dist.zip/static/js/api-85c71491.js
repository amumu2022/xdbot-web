import{aQ as e}from"./index-c6eb72b4.js";const o=t=>e.request("post","/api/v1/tools/send_email",{data:t}),p=t=>e.request("post","/api/v1/tools/text2pic",{data:t});export{p as A,o as a};
