import{_ as m}from"./description.vue_vue_type_style_index_0_lang-7e81f921.js";import"./index-ee2dd39d.js";export{m as default};
