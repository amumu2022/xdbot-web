import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-e5016282.js";import"./upload-9c186d09.js";import"./index-9387c28e.js";export{o as default};
