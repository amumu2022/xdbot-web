import{_ as o}from"./Sign.vue_vue_type_script_setup_true_lang-5c40c3c7.js";import"./dock-917d675f.js";import"./index-2459e2ab.js";export{o as default};
