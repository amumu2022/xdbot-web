import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-0b5aacde.js";import"./index-9fa96e67.js";import"./index-2459e2ab.js";export{o as default};
