import{_ as m}from"./LineChart.vue_vue_type_script_setup_true_lang-ab1d64e4.js";import"./index-2459e2ab.js";export{m as default};
