import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-41f5a8d3.js";import"./index-81ca0990.js";import"./index-27dc2674.js";export{o as default};
