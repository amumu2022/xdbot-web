import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-a4b6b2e2.js";import"./index-c6eb72b4.js";export{m as default};
