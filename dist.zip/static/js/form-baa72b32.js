import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-b186c30c.js";import"./index-6f723797.js";export{m as default};
