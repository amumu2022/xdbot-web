import{a0 as o}from"./index-2638da33.js";const a=o({});export{a as f};
