import{a$ as s,b0 as i}from"./index-302c85c2.js";function t(){return{isMobile:s(i).smaller("sm")}}export{t as u};
