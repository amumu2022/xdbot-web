import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-a0e1d4e7.js";import"./index-ee2dd39d.js";import"./index-5e916dd6.js";export{o as default};
