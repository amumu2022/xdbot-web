import{_ as m}from"./LineChart.vue_vue_type_script_setup_true_lang-b59a295b.js";import"./index-6f723797.js";export{m as default};
