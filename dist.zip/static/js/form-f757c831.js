import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-89b01abe.js";import"./index-2638da33.js";export{m as default};
