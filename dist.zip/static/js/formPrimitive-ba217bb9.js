import{_ as m}from"./formPrimitive.vue_vue_type_script_setup_true_lang-411cf9f3.js";import"./index-ee2dd39d.js";export{m as default};
