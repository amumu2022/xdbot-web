import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-dc7a3386.js";import"./upload-8e5aad99.js";import"./index-6f723797.js";export{o as default};
