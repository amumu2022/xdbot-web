import{_ as m}from"./description.vue_vue_type_style_index_0_lang-dda55523.js";import"./index-62eb8096.js";export{m as default};
