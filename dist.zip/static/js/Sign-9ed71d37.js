import{_ as o}from"./Sign.vue_vue_type_script_setup_true_lang-e3479ea5.js";import"./dock-767044c2.js";import"./index-f983c796.js";export{o as default};
