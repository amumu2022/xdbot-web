import{_ as o}from"./Sign.vue_vue_type_script_setup_true_lang-571a6149.js";import"./dock-9eedc705.js";import"./index-2638da33.js";export{o as default};
