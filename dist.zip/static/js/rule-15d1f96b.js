import{a0 as o}from"./index-62eb8096.js";const a=o({});export{a as f};
