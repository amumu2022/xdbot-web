import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-09133a2c.js";import"./upload-d83501d2.js";import"./index-2459e2ab.js";export{o as default};
