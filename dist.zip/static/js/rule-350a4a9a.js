import{Z as o}from"./index-ee2dd39d.js";const e=o({});export{e as f};
