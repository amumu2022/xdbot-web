import{a0 as o}from"./index-9387c28e.js";const a=o({});export{a as f};
