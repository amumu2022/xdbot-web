import{_ as m}from"./description.vue_vue_type_style_index_0_lang-c06a959f.js";import"./index-ee2dd39d.js";export{m as default};
