import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-fbde205d.js";import"./index-d1db311e.js";import"./index-9387c28e.js";export{o as default};
