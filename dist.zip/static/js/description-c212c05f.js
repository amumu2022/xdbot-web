import{_ as m}from"./description.vue_vue_type_style_index_0_lang-cf41a9d4.js";import"./index-c6eb72b4.js";export{m as default};
