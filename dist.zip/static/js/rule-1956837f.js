import{a0 as o}from"./index-2459e2ab.js";const a=o({});export{a as f};
