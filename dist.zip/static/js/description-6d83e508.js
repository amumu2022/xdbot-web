import{_ as m}from"./description.vue_vue_type_style_index_0_lang-86dc432b.js";import"./index-c6eb72b4.js";export{m as default};
