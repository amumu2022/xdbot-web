import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-e5d25f96.js";import"./upload-d75f46d8.js";import"./index-62eb8096.js";export{o as default};
