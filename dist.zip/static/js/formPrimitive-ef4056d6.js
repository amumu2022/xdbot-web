import{_ as m}from"./formPrimitive.vue_vue_type_script_setup_true_lang-24b872db.js";import"./index-f983c796.js";export{m as default};
