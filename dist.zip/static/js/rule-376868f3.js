import{a0 as o}from"./index-c6eb72b4.js";const a=o({});export{a as f};
