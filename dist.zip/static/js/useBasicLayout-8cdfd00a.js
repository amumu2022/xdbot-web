import{b8 as s,b9 as i}from"./index-62eb8096.js";function t(){return{isMobile:s(i).smaller("sm")}}export{t as u};
