import{_ as m}from"./description.vue_vue_type_style_index_0_lang-21f198c1.js";import"./index-27dc2674.js";export{m as default};
