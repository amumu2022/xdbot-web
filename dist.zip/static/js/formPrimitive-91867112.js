import{_ as m}from"./formPrimitive.vue_vue_type_script_setup_true_lang-63d388e0.js";import"./index-825ff3e3.js";export{m as default};
