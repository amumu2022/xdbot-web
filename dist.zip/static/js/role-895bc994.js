import{_ as o}from"./role.vue_vue_type_script_setup_true_lang-a1287c9f.js";import"./index-867f9eeb.js";import"./index-302c85c2.js";export{o as default};
