import{_ as m}from"./description.vue_vue_type_style_index_0_lang-73ed3995.js";import"./index-27dc2674.js";export{m as default};
