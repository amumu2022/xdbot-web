import{_ as m}from"./upload.vue_vue_type_script_setup_true_lang-ab841d7b.js";import"./index-825ff3e3.js";export{m as default};
