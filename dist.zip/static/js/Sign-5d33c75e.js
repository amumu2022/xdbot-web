import{_ as o}from"./Sign.vue_vue_type_script_setup_true_lang-b6e29aaa.js";import"./dock-b9a78cf8.js";import"./index-62eb8096.js";export{o as default};
