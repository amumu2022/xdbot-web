import{_ as m}from"./description.vue_vue_type_style_index_0_lang-eae33156.js";import"./index-6f723797.js";export{m as default};
