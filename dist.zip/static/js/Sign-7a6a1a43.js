import{_ as o}from"./Sign.vue_vue_type_script_setup_true_lang-77338529.js";import"./dock-851aa81f.js";import"./index-302c85c2.js";export{o as default};
