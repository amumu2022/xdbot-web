import{a_ as s,a$ as a}from"./index-9387c28e.js";function t(){return{isMobile:s(a).smaller("sm")}}export{t as u};
