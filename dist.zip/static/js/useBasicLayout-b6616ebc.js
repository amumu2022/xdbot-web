import{a_ as s,a$ as a}from"./index-825ff3e3.js";function t(){return{isMobile:s(a).smaller("sm")}}export{t as u};
