import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-0e7c66b2.js";import"./index-80faaafb.js";import"./index-6f723797.js";export{o as default};
