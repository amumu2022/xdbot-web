import{_ as o}from"./Sign.vue_vue_type_script_setup_true_lang-a9d73a57.js";import"./dock-6340eb7b.js";import"./index-c6eb72b4.js";export{o as default};
