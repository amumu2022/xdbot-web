import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-d41c67f9.js";import"./index-6f723797.js";export{m as default};
