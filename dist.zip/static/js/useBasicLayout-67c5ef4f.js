import{aY as s,aZ as a}from"./index-6f723797.js";function t(){return{isMobile:s(a).smaller("sm")}}export{t as u};
