import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-75604346.js";import"./index-6ed956f4.js";import"./index-c6eb72b4.js";export{o as default};
