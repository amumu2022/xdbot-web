import{_ as o}from"./role.vue_vue_type_script_setup_true_lang-60556dbc.js";import"./index-81ca0990.js";import"./index-27dc2674.js";export{o as default};
