import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-b9af8e35.js";import"./index-ee2dd39d.js";export{m as default};
