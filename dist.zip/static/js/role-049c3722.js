import{_ as o}from"./role.vue_vue_type_script_setup_true_lang-7ca84ce7.js";import"./index-6ed956f4.js";import"./index-c6eb72b4.js";export{o as default};
