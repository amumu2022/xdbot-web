import{_ as o}from"./TimeForm.vue_vue_type_script_setup_true_lang-1fa8e5fa.js";import"./index-27dc2674.js";import"./index-81ca0990.js";export{o as default};
