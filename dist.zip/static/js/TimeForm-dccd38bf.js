import{_ as o}from"./TimeForm.vue_vue_type_script_setup_true_lang-4b8107f5.js";import"./index-9387c28e.js";import"./index-d1db311e.js";export{o as default};
