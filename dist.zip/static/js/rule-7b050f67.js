import{a0 as o}from"./index-302c85c2.js";const a=o({});export{a as f};
