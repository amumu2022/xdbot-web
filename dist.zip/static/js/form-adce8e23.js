import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-2b0cd2e9.js";import"./index-3e9ad639.js";import"./index-62eb8096.js";export{o as default};
