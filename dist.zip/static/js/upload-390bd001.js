import{_ as m}from"./upload.vue_vue_type_script_setup_true_lang-7e980167.js";import"./index-2638da33.js";export{m as default};
