const t="/static/png/chatgpt-icon-92888469.png";export{t as c};
