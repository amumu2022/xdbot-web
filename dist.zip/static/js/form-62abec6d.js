import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-b0a60eb3.js";import"./index-d1db311e.js";import"./index-9387c28e.js";export{o as default};
