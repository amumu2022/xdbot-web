import{_ as o}from"./role.vue_vue_type_script_setup_true_lang-e6aaad58.js";import"./index-7aba79b2.js";import"./index-825ff3e3.js";export{o as default};
