import{_ as m}from"./description.vue_vue_type_style_index_0_lang-b12e479d.js";import"./index-302c85c2.js";export{m as default};
