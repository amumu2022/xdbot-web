import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-d3978816.js";import"./upload-782e83f5.js";import"./index-ee2dd39d.js";export{o as default};
