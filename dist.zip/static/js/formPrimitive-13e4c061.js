import{_ as m}from"./formPrimitive.vue_vue_type_script_setup_true_lang-d7435083.js";import"./index-6f723797.js";export{m as default};
