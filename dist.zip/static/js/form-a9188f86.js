import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-5fb7da83.js";import"./upload-d75f46d8.js";import"./index-62eb8096.js";export{o as default};
