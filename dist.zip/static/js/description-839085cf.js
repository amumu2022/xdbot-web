import{_ as m}from"./description.vue_vue_type_style_index_0_lang-ff22fa9d.js";import"./index-f983c796.js";export{m as default};
