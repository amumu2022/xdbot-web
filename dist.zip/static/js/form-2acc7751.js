import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-a4249754.js";import"./index-62eb8096.js";export{m as default};
