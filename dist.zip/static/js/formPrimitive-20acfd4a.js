import{_ as m}from"./formPrimitive.vue_vue_type_script_setup_true_lang-97aa6e8e.js";import"./index-f983c796.js";export{m as default};
