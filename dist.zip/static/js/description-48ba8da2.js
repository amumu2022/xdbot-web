import{_ as m}from"./description.vue_vue_type_style_index_0_lang-5c226d7e.js";import"./index-62eb8096.js";export{m as default};
