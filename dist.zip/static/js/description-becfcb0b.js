import{_ as m}from"./description.vue_vue_type_style_index_0_lang-dc5474e8.js";import"./index-2638da33.js";export{m as default};
