import{b1 as s,b2 as i}from"./index-2459e2ab.js";function t(){return{isMobile:s(i).smaller("sm")}}export{t as u};
