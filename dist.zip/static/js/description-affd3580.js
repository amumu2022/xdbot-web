import{_ as m}from"./description.vue_vue_type_style_index_0_lang-d77bb804.js";import"./index-6f723797.js";export{m as default};
