import{Y as o}from"./index-6f723797.js";const e=o({});export{e as f};
