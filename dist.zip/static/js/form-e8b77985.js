import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-aca76b0d.js";import"./index-80faaafb.js";import"./index-6f723797.js";import"./xdteam-1bd5232c.js";export{o as default};
