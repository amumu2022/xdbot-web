import{_ as o}from"./Sign.vue_vue_type_script_setup_true_lang-762da856.js";import"./dock-b6df0a24.js";import"./index-ee2dd39d.js";export{o as default};
