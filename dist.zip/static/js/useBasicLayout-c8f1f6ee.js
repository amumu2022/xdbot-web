import{b1 as s,b2 as i}from"./index-2638da33.js";function t(){return{isMobile:s(i).smaller("sm")}}export{t as u};
