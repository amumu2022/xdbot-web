import{a0 as o}from"./index-f983c796.js";const a=o({});export{a as f};
