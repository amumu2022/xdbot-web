import{_ as o}from"./Sign.vue_vue_type_script_setup_true_lang-55b724c5.js";import"./dock-5c435080.js";import"./index-825ff3e3.js";export{o as default};
