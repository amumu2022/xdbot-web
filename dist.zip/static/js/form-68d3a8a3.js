import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-22e6049f.js";import"./index-f983c796.js";export{m as default};
