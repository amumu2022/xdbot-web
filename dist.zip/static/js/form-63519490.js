import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-4c59e2bf.js";import"./upload-389f865b.js";import"./index-825ff3e3.js";export{o as default};
