import{_ as o}from"./Sign.vue_vue_type_script_setup_true_lang-065b3452.js";import"./dock-c620fb0d.js";import"./index-27dc2674.js";export{o as default};
