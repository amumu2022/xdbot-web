import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-6d1c5851.js";import"./index-d1db311e.js";import"./index-9387c28e.js";import"./xdteam-9f5cef6c.js";export{o as default};
