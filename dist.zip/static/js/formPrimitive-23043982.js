import{_ as m}from"./formPrimitive.vue_vue_type_script_setup_true_lang-c69423bb.js";import"./index-c6eb72b4.js";export{m as default};
