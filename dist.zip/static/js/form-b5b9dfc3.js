import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-c2f0dbcd.js";import"./index-9387c28e.js";export{m as default};
