import{b1 as s,b2 as i}from"./index-c6eb72b4.js";function t(){return{isMobile:s(i).smaller("sm")}}export{t as u};
