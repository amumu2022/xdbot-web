import{_ as m}from"./formPrimitive.vue_vue_type_script_setup_true_lang-fa79eaa2.js";import"./index-27dc2674.js";export{m as default};
