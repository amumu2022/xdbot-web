import{_ as m}from"./formPrimitive.vue_vue_type_script_setup_true_lang-accb73cd.js";import"./index-62eb8096.js";export{m as default};
