import{_ as o}from"./Sign.vue_vue_type_script_setup_true_lang-d759a830.js";import"./dock-ae07bcc2.js";import"./index-9387c28e.js";export{o as default};
