import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-402cf09e.js";import"./index-2459e2ab.js";export{m as default};
