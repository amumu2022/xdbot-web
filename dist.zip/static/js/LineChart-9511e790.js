import{_ as m}from"./LineChart.vue_vue_type_script_setup_true_lang-8534af45.js";import"./index-302c85c2.js";export{m as default};
