import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-6158dede.js";import"./upload-f484b04f.js";import"./index-c6eb72b4.js";export{o as default};
