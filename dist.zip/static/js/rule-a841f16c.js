import{a0 as o}from"./index-27dc2674.js";const a=o({});export{a as f};
