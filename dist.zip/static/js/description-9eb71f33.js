import{_ as m}from"./description.vue_vue_type_style_index_0_lang-23f3a98f.js";import"./index-9387c28e.js";export{m as default};
