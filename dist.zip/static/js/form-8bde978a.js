import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-c891c32f.js";import"./upload-8d31d2f2.js";import"./index-f983c796.js";export{o as default};
