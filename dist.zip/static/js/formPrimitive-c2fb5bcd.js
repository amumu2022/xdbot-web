import{_ as m}from"./formPrimitive.vue_vue_type_script_setup_true_lang-8a4a9f1a.js";import"./index-2459e2ab.js";export{m as default};
