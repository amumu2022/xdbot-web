import{a$ as s,b0 as i}from"./index-f983c796.js";function t(){return{isMobile:s(i).smaller("sm")}}export{t as u};
